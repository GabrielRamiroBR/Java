package com.company;

public abstract class Residencia {
    protected int numeroDeComodos;
    protected int numeroDeBanheiros;
    protected boolean temQuartoSeparado;
    protected boolean temSuite;

    public Residencia(int numeroDeComodos, int numeroDeBanheiros, boolean temQuartoSeparado, boolean temSuite) {
        this.numeroDeComodos = numeroDeComodos;
        this.numeroDeBanheiros = numeroDeBanheiros;
        this.temQuartoSeparado = temQuartoSeparado;
        this.temSuite = temSuite;
    }

    public float calculaIPTU() { return 2000;}

    public float calculaConsumoDeLuz() { return 4;}

    public String informacoes() {
        return String.format("Número de comodos %d; Número de banheiros %d; Tem quarto separado? %b; Tem suite? %b",
                numeroDeComodos, numeroDeBanheiros, temQuartoSeparado, temSuite);

    }

    public void ligaLuz() {
        System.out.println("Ligou a luz");
    }
    public void desligaLuz() {
        System.out.println("Desligou a luz");
    }

    public void receberCaixaDeCorreio(){
        System.out.println("Você recebeu o correio");
    }

    public int getNumeroDeComodos() {
        return numeroDeComodos;
    }

    public void setNumeroDeComodos(int numeroDeComodos) {
        this.numeroDeComodos = numeroDeComodos;
    }

    public int getNumeroDeBanheiros() {
        return numeroDeBanheiros;
    }

    public void setNumeroDeBanheiros(int numeroDeBanheiros) {
        this.numeroDeBanheiros = numeroDeBanheiros;
    }

    public boolean isTemQuartoSeparado() {
        return temQuartoSeparado;
    }

    public void setTemQuartoSeparado(boolean temQuartoSeparado) {
        this.temQuartoSeparado = temQuartoSeparado;
    }

    public boolean isTemSuite() {
        return temSuite;
    }

    public void setTemSuite(boolean temSuite) {
        this.temSuite = temSuite;
    }


}
