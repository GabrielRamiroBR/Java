package com.company;

public interface ReceberCorreio {

    void receberCaixaDeCorreio();
}
