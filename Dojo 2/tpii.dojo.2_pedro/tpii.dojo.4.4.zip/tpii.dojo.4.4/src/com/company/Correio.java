package com.company;

public interface Correio {

    void Correio();
}
