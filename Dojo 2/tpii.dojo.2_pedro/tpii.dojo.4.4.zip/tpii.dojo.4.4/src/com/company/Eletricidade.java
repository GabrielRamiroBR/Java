package com.company;

public interface Eletricidade {

    void ligaLuz();
    void desligaLuz();


}
